#ifndef SHT3X_H
#define SHT3X_H

#include <Arduino.h>
#include <Wire.h>

// SHT30默认I2C地址
#define SHT30_ADDR 0x44

// 全局变量声明
extern float sht30_temperature;
extern float sht30_humidity;

// 函数声明
void sht30_init_i2c(uint8_t sda_pin = SDA, uint8_t scl_pin = SCL);
bool sht30_read_data();
float sht30_get_temperature();
float sht30_get_humidity();
bool sht30_is_connected();

#endif
