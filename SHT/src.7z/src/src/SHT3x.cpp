#include "SHT3x.h"

// 全局变量定义
float sht30_temperature = 0.0;
float sht30_humidity = 0.0;

// 初始化I2C
void sht30_init_i2c(uint8_t sda_pin, uint8_t scl_pin) {
    #if defined(ESP32) || defined(ESP8266)
    if (sda_pin == SDA && scl_pin == SCL) {
        Wire.begin(); // 使用默认引脚
    } else {
        Wire.begin(sda_pin, scl_pin); // 使用指定引脚
    }
    #else
    Wire.begin(); // Arduino使用默认引脚
    #endif
    Serial.println("SHT30 I2C初始化完成");
}

// 读取SHT30传感器数据
bool sht30_read_data() {
    unsigned int sht30_data[6];
    
    // 发送测量命令
    Wire.beginTransmission(SHT30_ADDR);
    Wire.write(0x2C); // 测量命令
    Wire.write(0x06); // 高重复性测量
    Wire.endTransmission();
    delay(50); // 给传感器一些时间进行测量
    
    // 读取数据
    Wire.requestFrom(SHT30_ADDR, 6);
    if (Wire.available() == 6) {
        sht30_data[0] = Wire.read();
        sht30_data[1] = Wire.read();
        sht30_data[2] = Wire.read(); // CRC校验字节
        sht30_data[3] = Wire.read();
        sht30_data[4] = Wire.read();
        sht30_data[5] = Wire.read(); // CRC校验字节
        
        // 计算温度和湿度值
        sht30_temperature = ((((sht30_data[0] * 256.0) + sht30_data[1]) * 175) / 65535.0) - 45;
        sht30_humidity = ((((sht30_data[3] * 256.0) + sht30_data[4]) * 100) / 65535.0);
        
        return true; // 读取成功
    } else {
        // 数据读取失败
        sht30_temperature = -999.0;
        sht30_humidity = -999.0;
        Serial.println("无法读取SHT30数据");
        return false; // 读取失败
    }
}

// 获取温度值
float sht30_get_temperature() {
    return sht30_temperature;
}

// 获取湿度值
float sht30_get_humidity() {
    return sht30_humidity;
}

// 检查SHT30是否连接
bool sht30_is_connected() {
    Wire.beginTransmission(SHT30_ADDR);
    byte error = Wire.endTransmission();
    return (error == 0);
}