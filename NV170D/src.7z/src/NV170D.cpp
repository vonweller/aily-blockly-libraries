#include "NV170D.h"

NV170D::NV170D(int voicePin) {
    _voicePin = voicePin;
    pinMode(_voicePin, OUTPUT);
    digitalWrite(_voicePin, LOW);
}

void NV170D::sendData(int addr) {
    int addr_cp = addr;
    for (int i = 0; i < 8; i++) {
        sendBit(addr & 1);
        addr >>= 1;
    }
    digitalWrite(_voicePin, HIGH);

    _checksum += addr_cp;
    if(addr_cp == 0xF3){
        _checksum = (int32_t(_checksum)) % (int32_t(256));
	    this->sendData(_checksum);
    }
}

//sendDataWithStart
void NV170D::sendDWS(int addr) {
    digitalWrite(_voicePin, HIGH);
    delay(1);
    digitalWrite(_voicePin, LOW);
    delay(3);
    this->sendData(addr);

    if(addr == 0xF1){
        _checksum = addr;
    }
}

void NV170D::sendBit(int bit) {
    digitalWrite(_voicePin, HIGH);
    if (bit) {
        delayMicroseconds(2400);
        digitalWrite(_voicePin, LOW);
        delayMicroseconds(800);
    } else {
        delayMicroseconds(800);
        digitalWrite(_voicePin, LOW);
        delayMicroseconds(2400);
    }
}