#ifndef NV170D_H
#define NV170D_H

#include <Arduino.h>

class NV170D {
public:
    NV170D(int voicePin); // 构造函数，传入控制的 IO 引脚
    void sendData(int addr); // 发送数据
    void sendDWS(int addr); // 发送数据并启动

private:
    int _voicePin; // 控制的 IO 引脚
    volatile float _checksum = 0;//连码播放时数据暂存
    void sendBit(int bit); // 发送单个位
};

#endif