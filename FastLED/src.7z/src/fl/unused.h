#pragma once

#define FASTLED_UNUSED(x) (void)(x)