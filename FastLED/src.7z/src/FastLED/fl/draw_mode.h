#pragma once

namespace fl {

enum DrawMode { DRAW_MODE_OVERWRITE, DRAW_MODE_BLEND_BY_MAX_BRIGHTNESS };

} // namespace fl
