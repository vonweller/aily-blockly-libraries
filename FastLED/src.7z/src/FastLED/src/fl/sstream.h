#pragma once

#include "fl/strstream.h"

namespace fl {
using sstream = StrStream;
}