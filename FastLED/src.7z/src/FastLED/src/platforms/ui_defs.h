#pragma once

#ifdef __EMSCRIPTEN__
#include "platforms/wasm/js.h"
#else
// not defined for the system.
#endif