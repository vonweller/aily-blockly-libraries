#ifndef __INC_FASTLED_ARM_RP2040_H
#define __INC_FASTLED_ARM_RP2040_H

// Include the rp2040 headers
#include "fastpin_arm_rp2040.h"
#include "clockless_arm_rp2040.h"

#endif
