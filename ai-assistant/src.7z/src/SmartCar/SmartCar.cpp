#include "SmartCar.h"

// 分割字符串函数实现
int split(String str, String parts[], int maxParts) {
  int count = 0;
  str.trim();
  while (str.length() > 0 && count < maxParts) {
    int spaceIndex = str.indexOf(' ');
    if (spaceIndex == -1) {
      parts[count++] = str;
      break;
    } else {
      parts[count++] = str.substring(0, spaceIndex);
      str = str.substring(spaceIndex + 1);
      str.trim();
    }
  }
  return count;
}

// 构造函数
SmartCar::SmartCar() : 
    softSerial(SOFT_SERIAL_RX, SOFT_SERIAL_TX),
    inputCommand(""),
    lastCommand(""),
    ledBlinking(false),
    ledState(false),
    ledPreviousMillis(0),
    ledInterval(1000)
{
}

// 带引脚参数的构造函数
SmartCar::SmartCar(uint8_t rxPin, uint8_t txPin) : 
    softSerial(rxPin, txPin),
    inputCommand(""),
    lastCommand(""),
    ledBlinking(false),
    ledState(false),
    ledPreviousMillis(0),
    ledInterval(1000)
{
}

// 初始化
void SmartCar::begin() {
    // 初始化串口
    Serial.begin(9600);
    softSerial.begin(9600); // 初始化软串口用于接收数据
    
    // 初始化引脚
    pinMode(MOTOR_LEFT_DIR, OUTPUT);
    pinMode(MOTOR_LEFT_PWM, OUTPUT);
    pinMode(MOTOR_RIGHT_DIR, OUTPUT);
    pinMode(MOTOR_RIGHT_PWM, OUTPUT);
    pinMode(FAN_PIN, OUTPUT);
    pinMode(LED_PIN, OUTPUT);
    
    // 初始化RGB灯带
    neoPixel.begin(RGB_PIN, 4); // A0引脚，4颗灯珠
    neoPixel.setBrightness(50); // 默认亮度50%
    neoPixel.clear(); // 清除所有灯效果
    neoPixel.show(); // 显示更新
    
    // 初始化舵机引脚
    pinMode(SERVO_PIN, OUTPUT); // 舵机连接到D10引脚
    // 默认设置为中间位置 (90度)
    analogWrite(SERVO_PIN, map(90, 0, 180, 0, 255));
    currentServoAngle = 90;
    
    // 初始状态LED关闭
    digitalWrite(LED_PIN, LOW);
    
    Serial.println("智能小车初始化完成!");
    Serial.println("等待软串口命令...");
}

// 小车前进，speed为0-100的百分比
void SmartCar::moveForward(int speed) {
    // 将百分比速度(0-100)映射到PWM值(0-255)
    int pwmSpeed = map(speed, 0, 100, 0, 255);
    
    digitalWrite(MOTOR_LEFT_DIR, HIGH);   // 左电机正转
    analogWrite(MOTOR_LEFT_PWM, 255-pwmSpeed);  // 左电机速度控制
    digitalWrite(MOTOR_RIGHT_DIR, HIGH);  // 右电机正转
    analogWrite(MOTOR_RIGHT_PWM, 255-pwmSpeed); // 右电机速度控制
}

// 小车后退，speed为0-100的百分比
void SmartCar::moveBackward(int speed) {
    // 将百分比速度(0-100)映射到PWM值(0-255)
    int pwmSpeed = map(speed, 0, 100, 0, 255);
    
    digitalWrite(MOTOR_LEFT_DIR, LOW);    // 左电机反转
    analogWrite(MOTOR_LEFT_PWM, 255-pwmSpeed);  // 左电机速度控制
    digitalWrite(MOTOR_RIGHT_DIR, LOW);   // 右电机反转
    analogWrite(MOTOR_RIGHT_PWM, 255-pwmSpeed); // 右电机速度控制
}

// 小车左转，speed为0-100的百分比
void SmartCar::turnLeft(int speed) {
    // 将百分比速度(0-100)映射到PWM值(0-255)
    int pwmSpeed = map(speed, 0, 100, 0, 255);
    
    digitalWrite(MOTOR_LEFT_DIR, LOW);    // 左电机反转
    analogWrite(MOTOR_LEFT_PWM, 255-pwmSpeed);  // 左电机速度控制
    digitalWrite(MOTOR_RIGHT_DIR, HIGH);  // 右电机正转
    analogWrite(MOTOR_RIGHT_PWM, 255-pwmSpeed); // 右电机速度控制
}

// 小车右转，speed为0-100的百分比
void SmartCar::turnRight(int speed) {
    // 将百分比速度(0-100)映射到PWM值(0-255)
    int pwmSpeed = map(speed, 0, 100, 0, 255);
    
    digitalWrite(MOTOR_LEFT_DIR, HIGH);   // 左电机正转
    analogWrite(MOTOR_LEFT_PWM, 255-pwmSpeed);  // 左电机速度控制
    digitalWrite(MOTOR_RIGHT_DIR, LOW);   // 右电机反转
    analogWrite(MOTOR_RIGHT_PWM, 255-pwmSpeed); // 右电机速度控制
}

// 小车停止
void SmartCar::stop() {
    digitalWrite(MOTOR_LEFT_DIR, HIGH);   // 左电机方向
    analogWrite(MOTOR_LEFT_PWM, 255);     // 左电机速度为0
    digitalWrite(MOTOR_RIGHT_DIR, HIGH);  // 右电机方向
    analogWrite(MOTOR_RIGHT_PWM, 255);    // 右电机速度为0
}

// LED控制 - 开/关
void SmartCar::setLed(bool state) {
    ledBlinking = false;  // 关闭闪烁模式
    ledState = state;
    digitalWrite(LED_PIN, state ? HIGH : LOW);
}

// LED控制 - 闪烁
void SmartCar::blinkLed(int rate) {
    if (rate <= 0) rate = 1;
    ledInterval = 1000 / rate;  // 计算闪烁间隔
    ledPreviousMillis = millis();
    ledState = true;
    digitalWrite(LED_PIN, HIGH);  // 初始状态设置为开
    ledBlinking = true;  // 启动闪烁模式
}

// LED闪烁更新 - 需要在主循环中调用
void SmartCar::updateLedBlink() {
    if (ledBlinking) {
        unsigned long currentMillis = millis();
        if (currentMillis - ledPreviousMillis >= ledInterval) {
            ledPreviousMillis = currentMillis;
            ledState = !ledState;
            digitalWrite(LED_PIN, ledState ? HIGH : LOW);
        }
    }
}

// 处理软串口输入
void SmartCar::processSerialInput() {
    // 更新LED闪烁状态
    updateLedBlink();
    
    // 从软串口接收数据
    while (softSerial.available()) {
        char c = (char)softSerial.read();

        if ((c < 32 && c != '\n' && c != '\r') || c > 126) {
            continue;
        }

        if (c == '\n' || c == '\r') {
            inputCommand.trim();
            if (inputCommand.length() > 0 && inputCommand != lastCommand) {
                Serial.print("收到新命令：");
                Serial.println(inputCommand);
                handleCommand(inputCommand);
                lastCommand = inputCommand;
            }
            inputCommand = "";
        } else {
            inputCommand += c;
        }
    }
}

// 新增: 仅获取命令内容而不处理
String SmartCar::getSerialCommand() {
    // 更新LED闪烁状态
    updateLedBlink();
    
    String command = "";
    bool newCommand = false;
    
    // 从软串口接收数据
    while (softSerial.available()) {
        char c = (char)softSerial.read();

        if ((c < 32 && c != '\n' && c != '\r') || c > 126) {
            continue;
        }

        if (c == '\n' || c == '\r') {
            inputCommand.trim();
            if (inputCommand.length() > 0) {
                command = inputCommand;
                newCommand = true;
                Serial.print("软串口接收到命令：");
                Serial.println(command);
            }
            inputCommand = "";
        } else {
            inputCommand += c;
        }
    }
    
    return command;
}

// 处理命令
void SmartCar::handleCommand(String cmd) {
    cmd.trim();
    if (cmd.startsWith("MOVE")) {
        handleMove(cmd);
    } else if (cmd.startsWith("LED")) {
        handleLed(cmd);
    } else if (cmd.startsWith("RGB")) {
        handleRGB(cmd);
    } else if (cmd.startsWith("SERVO")) {
        handleServo(cmd);
    } else if (cmd.startsWith("FAN")) {
        handleFan(cmd);
    } else {
        Serial.print("未知命令：");
        Serial.println(cmd);
    }
}

// 处理移动命令
void SmartCar::handleMove(String cmd) {
    String parts[3];
    int count = split(cmd, parts, 3);
    char direction = 'S';
    int speed = 50;

    if (count >= 2) direction = parts[1].charAt(0);
    if (count == 3) speed = parts[2].toInt();
    
    // 限制速度范围在0-100之间
    if (speed < 0) speed = 0;
    if (speed > 100) speed = 100;

    Serial.print("小车控制 -> 方向: ");
    Serial.print(direction);
    if (direction != 'S') {
        Serial.print(" 速度: ");
        Serial.print(speed);
        Serial.print("%");
    }
    Serial.println();
    
    // 根据方向控制小车
    switch(direction) {
        case 'F':  // 前进
            moveForward(speed);
            break;
        case 'B':  // 后退
            moveBackward(speed);
            break;
        case 'L':  // 左转
            turnLeft(speed);
            break;
        case 'R':  // 右转
            turnRight(speed);
            break;
        case 'S':  // 停止
        default:
            stop();
            break;
    }
}

// 处理LED命令
void SmartCar::handleLed(String cmd) {
    String parts[6];
    int count = split(cmd, parts, 6);

    if (count < 3) {
        Serial.println("LED控制 -> 参数不足");
        return;
    }

    String id = parts[1];
    String action = parts[2];

    if (action == "ON") {
        Serial.print("LED控制 -> 开启 LED ");
        // 关闭闪烁模式
        ledBlinking = false;
        // 直接开启LED
        digitalWrite(LED_PIN, HIGH); 
        ledState = true;
        Serial.println(id);
    } else if (action == "OFF") {
        Serial.print("LED控制 -> 关闭 LED ");
        // 关闭闪烁模式
        ledBlinking = false;
        // 关闭LED
        digitalWrite(LED_PIN, LOW); 
        ledState = false;
        Serial.println(id);
    } else if (action == "BLINK") {
        if (count >= 4) {
            int blinkRate = parts[3].toInt();
            // 确保频率有效性
            if (blinkRate <= 0) blinkRate = 1;
            
            // 设置新的闪烁时间间隔（毫秒）
            ledInterval = 1000 / blinkRate;
            
            Serial.print("LED控制 -> LED ");
            Serial.print(id);
            Serial.print(" 闪烁频率: ");
            Serial.print(blinkRate);
            Serial.print(" 次/秒 (时间间隔: ");
            Serial.print(ledInterval);
            Serial.println("ms)");
            
            // 重置状态变量
            ledPreviousMillis = millis();
            ledState = true;
            digitalWrite(LED_PIN, HIGH); // 初始状态设置为开
            
            // 启动闪烁模式
            ledBlinking = true;
        } else {
            Serial.println("LED控制 -> 闪烁命令缺少频率参数");
        }
    } else {
        Serial.println("LED控制 -> 命令格式错误");
    }
}

// 处理RGB命令
void SmartCar::handleRGB(String cmd) {
    String parts[6];
    int count = split(cmd, parts, 6);

    if (count < 3) {
        Serial.println("RGB控制 -> 参数不足");
        return;
    }

    int id = parts[1].toInt();
    String action = parts[2];
    
    // 处理开关命令
    if (action == "ON") {
        // 打开RGB灯带，默认显示白色
        for (int i = 0; i < 4; i++) {
            neoPixel.setPixelColor(i, 255, 255, 255);
        }
        neoPixel.show();
        Serial.print("RGB控制 -> 打开RGB灯 ");
        Serial.println(id);
    } 
    else if (action == "OFF") {
        // 关闭RGB灯带
        neoPixel.clear();
        neoPixel.show();
        Serial.print("RGB控制 -> 关闭RGB灯 ");
        Serial.println(id);
    }
    // 处理亮度控制命令 - 同时支持LIGHT和BRIGHTNESS两种命令格式
    else if ((action == "LIGHT" || action == "BRIGHTNESS") && count >= 4) {
        // 解析带方括号的参数
        String brightnessStr = parts[3];
        brightnessStr.replace("[", "");
        brightnessStr.replace("]", "");
        
        int brightness = brightnessStr.toInt();
        // 确保亮度在0-100范围内
        if (brightness < 0) brightness = 0;
        if (brightness > 100) brightness = 100;
        
        // 将亮度从百分比(0-100)映射到NeoPixel亮度值(0-255)
        int pixelBrightness = map(brightness, 0, 100, 0, 255);
        neoPixel.setBrightness(pixelBrightness);
        
        // 确保有像素可显示(如果是黑色就看不到亮度变化)
        for (int i = 0; i < 4; i++) {
            neoPixel.setPixelColor(i, 255, 255, 255); // 设置为白色
        }
        neoPixel.show();
        
        Serial.print("RGB控制 -> RGB灯 ");
        Serial.print(id);
        Serial.print(" 亮度: ");
        Serial.print(brightness);
        Serial.println("%");
    }
    // 处理渐变效果命令
    else if (action == "GRADIENT" && count >= 5) {
        // 解析带方括号的参数
        String startColorStr = parts[3];
        String endColorStr = parts[4];
        
        // 去除方括号
        startColorStr.replace("[", "");
        startColorStr.replace("]", "");
        endColorStr.replace("[", "");
        endColorStr.replace("]", "");
        
        int startColor = startColorStr.toInt();
        int endColor = endColorStr.toInt();
        
        Serial.print("RGB控制 -> RGB灯 ");
        Serial.print(id);
        Serial.print(" 渐变: ");
        Serial.print(startColor);
        Serial.print(" 到 ");
        Serial.println(endColor);
        
        // 显示彩虹渐变效果
        neoPixel.showRainbow(0, 3, startColor, endColor);
    }
    else {
        Serial.println("RGB控制 -> 命令格式错误");
    }
}

// 处理舵机命令
void SmartCar::handleServo(String cmd) {
    String parts[4];
    int count = split(cmd, parts, 4);

    if (count < 3) {
        Serial.println("舵机控制 -> 参数不足");
        return;
    }

    // 解析带方括号的参数
    String idStr = parts[1];
    String angleStr = parts[2];
    
    // 去除方括号
    idStr.replace("[", "");
    idStr.replace("]", "");
    angleStr.replace("[", "");
    angleStr.replace("]", "");
    
    int id = idStr.toInt();
    int angle = angleStr.toInt();
    
    // 限制角度范围
    if (angle < 0) angle = 0;
    if (angle > 180) angle = 180;
    
    // 设置舵机角度
    setServoAngle(id, angle);

    Serial.print("舵机控制 -> 舵机ID: ");
    Serial.print(id);
    Serial.print(" 角度: ");
    Serial.println(angle);
}

// 处理风扇命令
void SmartCar::handleFan(String cmd) {
    String parts[3];
    int count = split(cmd, parts, 3);
    
    // 默认速度为50%
    int speed = 50;
    
    // 如果命令中包含速度参数，则解析速度值
    if (count >= 2) {
        // 检查参数格式，如果是 [50] 这种格式，需要去除方括号
        String speedStr = parts[1];
        speedStr.replace("[", "");
        speedStr.replace("]", "");
        speed = speedStr.toInt();
        // 确保速度在0-100的范围内
        if (speed < 0) speed = 0;
        if (speed > 100) speed = 100;
    }
    
    // 输出状态信息
    if (speed == 0) {
        Serial.println("风扇控制 -> 关闭");
    } else {
        Serial.print("风扇控制 -> 开启，速度: ");
        Serial.print(speed);
        Serial.println("%");
    }
    
    // 控制风扇速度
    setFanSpeed(speed);
}

// RGB灯带控制 - 开
void SmartCar::setRgbOn() {
    for (int i = 0; i < 4; i++) {
        neoPixel.setPixelColor(i, 255, 255, 255);  // 默认白色
    }
    neoPixel.show();
}

// RGB灯带控制 - 关
void SmartCar::setRgbOff() {
    neoPixel.clear();
    neoPixel.show();
}

// RGB灯带控制 - 亮度
void SmartCar::setRgbBrightness(int brightness) {
    // 确保亮度在0-100范围内
    brightness = constrain(brightness, 0, 100);
    // 将亮度从百分比(0-100)映射到NeoPixel亮度值(0-255)
    int pixelBrightness = map(brightness, 0, 100, 0, 255);
    neoPixel.setBrightness(pixelBrightness);
    neoPixel.show();
}

// RGB灯带控制 - 渐变
void SmartCar::setRgbGradient(int startColor, int endColor) {
    neoPixel.showRainbow(0, 3, startColor, endColor);
}

// 风扇控制
void SmartCar::setFanSpeed(int speed) {
    // 确保速度在0-100的范围内
    if (speed < 0) speed = 0;
    if (speed > 100) speed = 100;
    
    // 将百分比转换为PWM值(0-255)
    int pwmValue = map(speed, 0, 100, 0, 255);
    analogWrite(FAN_PIN, pwmValue);
}

// 设置舵机角度
void SmartCar::setServoAngle(int id, int angle) {
    // 目前只支持一个舵机，id参数留作将来扩展用途
    // 限制角度范围在0-180度
    if (angle < 0) angle = 0;
    if (angle > 180) angle = 180;
    
    // Arduino标准舵机控制使用44-205的数值对应0-180度
    // 使用writeMicroseconds()时范围为1000-2000
    // 这里我们使用analogWrite直接输出PWM
    int pulseWidth = map(angle, 0, 180, 50, 250);
    analogWrite(SERVO_PIN, pulseWidth);
    
    // 输出调试信息
    Serial.print("舵机控制 -> 设置角度: ");
    Serial.print(angle);
    Serial.print(" PWM值: ");
    Serial.println(pulseWidth);
}
