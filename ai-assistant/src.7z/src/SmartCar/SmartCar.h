#ifndef SMART_CAR_H
#define SMART_CAR_H

#include <Arduino.h>
#include <SoftwareSerial.h>
#include <DFRobot_NeoPixel.h>

// 分割字符串函数声明
int split(String str, String parts[], int maxParts);

// 命名空间形式的枚举定义，以便与生成的代码兼容
namespace MOVE_DIRECTION {
    enum Value {
        FORWARD,
        BACKWARD,
        LEFT,
        RIGHT,
        STOP
    };
}

namespace LED_ACTION {
    enum Value {
        ON,
        OFF,
        BLINK
    };
}

namespace RGB_ACTION {
    enum Value {
        ON,
        OFF,
        BRIGHTNESS,
        GRADIENT
    };
}

class SmartCar {
public:
    SmartCar();
    // 新增：带引脚参数的构造函数
    SmartCar(uint8_t rxPin, uint8_t txPin);
    
    // 初始化
    void begin();
    
    // 串口命令处理函数
    void processSerialInput();
    String getSerialCommand(); // 新增：仅获取命令但不处理
    void handleCommand(String cmd);
    void handleMove(String cmd);
    void handleLed(String cmd);
    void handleRGB(String cmd);
    void handleServo(String cmd);
    void handleFan(String cmd);
    
    // 移动控制
    void moveForward(int speed);
    void moveBackward(int speed);
    void turnLeft(int speed);
    void turnRight(int speed);
    void stop();
    
    // LED控制
    void setLed(bool state);
    void blinkLed(int rate);
    void updateLedBlink(); // 需要在loop中调用
    
    // RGB控制
    void setRgbOn();
    void setRgbOff();
    void setRgbBrightness(int brightness);
    void setRgbGradient(int startColor, int endColor);
    
    // 风扇控制
    void setFanSpeed(int speed);
    
    // 舵机控制
    void setServoAngle(int id, int angle);  // 设置舵机角度
    
private:
    // 电机控制引脚定义
    static const int MOTOR_LEFT_DIR = 4;    // 左电机方向控制引脚
    static const int MOTOR_LEFT_PWM = 5;    // 左电机 PWM速度控制引脚
    static const int MOTOR_RIGHT_DIR = 7;   // 右电机方向控制引脚
    static const int MOTOR_RIGHT_PWM = 6;   // 右电机 PWM速度控制引脚
    static const int FAN_PIN = 9;           // 风扇控制引脚
    static const int LED_PIN = 13;          // LED控制引脚
    static const int RGB_PIN = A0;          // RGB控制引脚
    static const int SERVO_PIN = 10;        // 舵机控制引脚
    static const int SOFT_SERIAL_RX = A2;   // 软串口RX
    static const int SOFT_SERIAL_TX = 8;    // 软串口TX
    
    // 软串口
    SoftwareSerial softSerial;
    String inputCommand;
    String lastCommand;
    
    // RGB灯带
    DFRobot_NeoPixel neoPixel;
    
    // 舵机直接PWM控制相关变量
    int currentServoAngle;
    
    // LED闪烁控制变量
    bool ledBlinking;
    bool ledState;
    unsigned long ledPreviousMillis;
    unsigned long ledInterval;
};

#endif
