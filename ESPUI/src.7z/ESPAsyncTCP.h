#ifndef ESPAsyncTCP_h
#define ESPAsyncTCP_h

// ESPUI ESPAsyncTCP wrapper header for ESP8266
#ifdef ESP8266
#include "ESPAsyncTCP/ESPAsyncTCP.h"
#endif

#endif