// Placeholder to prevent compilation errors
#pragma once
#include "../../ArduinoJson.h"
