#ifndef AsyncTCP_h
#define AsyncTCP_h

// ESPUI AsyncTCP wrapper header for ESP32
#ifdef ESP32
#include "AsyncTCP/AsyncTCP.h"
#endif

#endif