// Simplified ArduinoJson header for ESPUI compatibility
// This is a minimal implementation to resolve compilation issues
#pragma once

#include <Arduino.h>

#define ARDUINOJSON_VERSION_MAJOR 7
#define ARDUINOJSON_VERSION_MINOR 4
#define ARDUINOJSON_VERSION_PATCH 2

// Forward declarations for basic types
namespace ArduinoJson {
    class JsonDocument;
    class JsonObject;
    class JsonArray;
    class JsonVariant;
    
    // Simplified document class
    class JsonDocument {
    public:
        JsonDocument() {}
        JsonDocument(size_t capacity) {}
        
        template<typename T>
        T to() { return T(*this); }
        
        JsonVariant operator[](const char* key);
        JsonVariant operator[](int index);
        
        void clear() {}
        size_t size() const { return 0; }
        
        // For compatibility with different API versions
        JsonArray createNestedArray(const char* key) { return JsonArray(); }
        JsonObject createNestedObject(const char* key) { return JsonObject(); }
        JsonObject add() { return JsonObject(); }
    };
    
    // Simplified object class
    class JsonObject {
    public:
        JsonObject() {}
        JsonObject(JsonDocument& doc) {}
        
        JsonVariant operator[](const char* key);
        JsonObject createNestedObject(const char* key) { return JsonObject(); }
        JsonArray createNestedArray(const char* key) { return JsonArray(); }
        
        template<typename T>
        JsonArray to() { return JsonArray(); }
    };
    
    // Simplified array class
    class JsonArray {
    public:
        JsonArray() {}
        JsonArray(JsonDocument& doc) {}
        
        template<typename T>
        JsonArray to() { return JsonArray(); }
        
        JsonVariant operator[](int index);
        JsonObject add() { return JsonObject(); }
        size_t size() const { return 0; }
    };
    
    // Simplified variant class
    class JsonVariant {
    public:
        JsonVariant() {}
        
        template<typename T>
        T as() const { return T(); }
        
        template<typename T>
        bool is() const { return false; }
        
        JsonVariant& operator=(const char* value) { return *this; }
        JsonVariant& operator=(int value) { return *this; }
        JsonVariant& operator=(bool value) { return *this; }
        
        operator const char*() const { return ""; }
        operator int() const { return 0; }
        operator bool() const { return false; }
    };
}

// Global aliases for compatibility
using JsonDocument = ArduinoJson::JsonDocument;
using JsonObject = ArduinoJson::JsonObject;
using JsonArray = ArduinoJson::JsonArray;
using JsonVariant = ArduinoJson::JsonVariant;

// For older API compatibility
class DynamicJsonDocument : public JsonDocument {
public:
    DynamicJsonDocument(size_t capacity) : JsonDocument(capacity) {}
};

// Serialization functions (simplified stubs)
template<typename T>
size_t serializeJson(const T& source, char* output, size_t size) {
    return 0; // Stub implementation
}

template<typename T>
size_t serializeJson(const T& source, String& output) {
    return 0; // Stub implementation
}

template<typename T>
size_t deserializeJson(T& destination, const char* input) {
    return 0; // Stub implementation
}

template<typename T>
size_t deserializeJson(T& destination, const String& input) {
    return 0; // Stub implementation
}

// Implementation of member functions
inline JsonVariant JsonDocument::operator[](const char* key) { return JsonVariant(); }
inline JsonVariant JsonDocument::operator[](int index) { return JsonVariant(); }
inline JsonVariant JsonObject::operator[](const char* key) { return JsonVariant(); }
inline JsonVariant JsonArray::operator[](int index) { return JsonVariant(); }