#ifndef WIND_H
#define WIND_H

#include <Arduino.h>

class WindSpeed {
private:
    // 风速相关变量
    static byte windSpeedPin;
    static volatile long lastWindIRQ;
    static volatile byte windClicks;
    static long lastWindCheck;
    static long lastSecond;
    static float windspeedKmh;
    
    // 风向相关变量
    static byte windDirPin;
    static int windDirection;
    static unsigned int adc_cp;
    
    // 私有函数
    static void wspeedIRQ();
    static float get_wind_speed();
    static int get_wind_direction();
    
public:
    // 初始化函数
    static void begin(byte speedPin, byte dirPin);
    static void beginWindSpeed(byte speedPin);
    static void beginWindDirection(byte dirPin);
    
    // 更新函数
    static void update();
    static void updateWindSpeed();
    static void updateWindDirection();
    
    // 风速获取函数
    static float getWindSpeed();
    static float getWindSpeedMph();
    
    // 风向获取函数
    static int getWindDirection();
    static String getWindDirectionString();
    static unsigned int getWindDirectionADC();
    
    // 打印函数
    static void printWindSpeed();
    static void printWindDirection();
    static void printAllData();
    
    // 状态检查函数
    static bool isDataReady();
};

#endif