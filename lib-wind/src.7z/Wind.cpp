#include "Wind.h"

// 静态成员变量定义 - 风速
byte WindSpeed::windSpeedPin = 35;
volatile long WindSpeed::lastWindIRQ = 0;
volatile byte WindSpeed::windClicks = 0;
long WindSpeed::lastWindCheck = 0;
long WindSpeed::lastSecond = 0;
float WindSpeed::windspeedKmh = 0;

// 静态成员变量定义 - 风向
byte WindSpeed::windDirPin = 34;
int WindSpeed::windDirection = 0;
unsigned int WindSpeed::adc_cp = 0;

// 同时初始化风速和风向传感器
void WindSpeed::begin(byte speedPin, byte dirPin) {
    beginWindSpeed(speedPin);
    beginWindDirection(dirPin);
    Serial.println("Wind Speed & Direction Sensors initialized!");
}

// 仅初始化风速传感器
void WindSpeed::beginWindSpeed(byte speedPin) {
    windSpeedPin = speedPin;
    pinMode(windSpeedPin, INPUT);
    
    lastSecond = millis();
    lastWindCheck = millis();
    windClicks = 0;
    windspeedKmh = 0;
    
    // 附加中断
    attachInterrupt(digitalPinToInterrupt(windSpeedPin), wspeedIRQ, FALLING);
    interrupts();
    
    Serial.println("Wind Speed Sensor initialized!");
}

// 仅初始化风向传感器
void WindSpeed::beginWindDirection(byte dirPin) {
    windDirPin = dirPin;
    windDirection = 0;
    adc_cp = 0;
    
    Serial.println("Wind Direction Sensor initialized!");
}

// 风速中断服务函数
void WindSpeed::wspeedIRQ() {
    // 消抖处理：忽略10ms内的重复触发
    if (millis() - lastWindIRQ > 10) {
        lastWindIRQ = millis();
        windClicks++;
    }
}

// 获取风速（内部函数）
float WindSpeed::get_wind_speed() {
    float deltaTime = millis() - lastWindCheck;
    deltaTime /= 1000.0; // 转换为秒
    
    float windSpeed = (float)windClicks / deltaTime;
    windClicks = 0; // 重置计数
    lastWindCheck = millis();
    
    windSpeed *= 1.492; // 转换为英里/小时
    
    return windSpeed;
}

// 获取风向（内部函数）
int WindSpeed::get_wind_direction() {
    unsigned int adc;
    
    adc = analogRead(windDirPin); // 读取当前传感器值
    
    // ESP32 ADC采样精度（12位）大于Arduino(10位)，需要除以4
    #ifdef ESP32
        adc /= 4;
    #endif
    
    adc_cp = adc; // 保存ADC值用于调试
    
    // 根据ADC值判断风向
    if (adc < 85) return 0;      // E  东
    if (adc < 154) return 315;   // NW 西北
    if (adc < 264) return 270;   // W  西
    if (adc < 481) return 45;    // NE 东北
    if (adc < 615) return 225;   // SW 西南
    if (adc < 782) return 90;    // N  北
    if (adc < 902) return 135;   // SE 东南
    if (adc < 1024) return 180;  // S  南
    
    return -1; // 错误，可能断线
}

// 更新所有数据
void WindSpeed::update() {
    updateWindSpeed();
    updateWindDirection();
}

// 更新风速数据
void WindSpeed::updateWindSpeed() {
    // 每秒更新一次风速
    if (millis() - lastSecond >= 1000) {
        lastSecond += 1000;
        
        float currentSpeedMph = get_wind_speed();
        windspeedKmh = currentSpeedMph * 1.609344; // 转换为千米/小时
    }
}

// 更新风向数据
void WindSpeed::updateWindDirection() {
    windDirection = get_wind_direction();
}

// 获取风速（千米/小时）
float WindSpeed::getWindSpeed() {
    return windspeedKmh;
}

// 获取风速（英里/小时）
float WindSpeed::getWindSpeedMph() {
    return windspeedKmh / 1.609344;
}

// 获取风向（度数）
int WindSpeed::getWindDirection() {
    return windDirection;
}

// 获取风向（字符串）
String WindSpeed::getWindDirectionString() {
    switch (windDirection) {
        case 0:   return "E";    // 东
        case 45:  return "NE";   // 东北
        case 90:  return "N";    // 北
        case 135: return "NW";   // 西北 (应该是SE东南)
        case 180: return "S";    // 南
        case 225: return "SW";   // 西南
        case 270: return "W";    // 西
        case 315: return "NW";   // 西北
        case -1:  return "ERROR"; // 错误
        default:  return "UNKNOWN";
    }
}

// 获取风向ADC原始值
unsigned int WindSpeed::getWindDirectionADC() {
    return adc_cp;
}

// 打印风速
void WindSpeed::printWindSpeed() {
    Serial.print("windspeed=");
    Serial.print(windspeedKmh, 1);
    Serial.println("km/h");
}

// 打印风向
void WindSpeed::printWindDirection() {
    Serial.print("adc:");
    Serial.print(adc_cp);
    Serial.print("  dir:");
    Serial.print(windDirection);
    Serial.print("° (");
    Serial.print(getWindDirectionString());
    Serial.println(")");
}

// 打印所有数据
void WindSpeed::printAllData() {
    Serial.print("Wind: ");
    Serial.print(windspeedKmh, 1);
    Serial.print("km/h, ");
    Serial.print(windDirection);
    Serial.print("° (");
    Serial.print(getWindDirectionString());
    Serial.print("), ADC:");
    Serial.println(adc_cp);
}

// 检查数据是否准备就绪
bool WindSpeed::isDataReady() {
    static long lastUpdate = 0;
    if (millis() - lastUpdate >= 1000) {
        lastUpdate = millis();
        return true;
    }
    return false;
}