#ifndef WIND_H
#define WIND_H

#include <Arduino.h>

// 常量定义
#define S_IN_DAY   86400        // 一天的秒数
#define S_IN_HR     3600        // 一小时的秒数
#define NO_RAIN_SAMPLES 2000    // 最大雨滴事件存储数量

class WindSpeed {
private:
    // 风速相关变量
    static byte windSpeedPin;
    static volatile long lastWindIRQ;
    static volatile byte windClicks;
    static long lastWindCheck;
    static long lastSecond;
    static float windspeedKmh;
    
    // 风向相关变量
    static byte windDirPin;
    static int windDirection;
    static unsigned int adc_cp;
    
    // 私有函数
    static void wspeedIRQ();
    static float get_wind_speed();
    static int get_wind_direction();
    
public:
    // 初始化函数
    static void begin(byte speedPin, byte dirPin);
    static void beginWindSpeed(byte speedPin);
    static void beginWindDirection(byte dirPin);
    
    // 更新函数
    static void update();
    static void updateWindSpeed();
    static void updateWindDirection();
    
    // 风速获取函数
    static float getWindSpeed();
    static float getWindSpeedMph();
    
    // 风向获取函数
    static int getWindDirection();
    static String getWindDirectionString();
    static unsigned int getWindDirectionADC();
    
    // 打印函数
    static void printWindSpeed();
    static void printWindDirection();
    static void printAllData();
    
    // 状态检查函数
    static bool isDataReady();
};

class RainSensor {
private:
    // 静态成员变量
    static byte rainPin;
    static volatile long rainTickList[NO_RAIN_SAMPLES];
    static volatile int rainTickIndex;
    static volatile int rainTicks;
    static volatile int rainTicks_outvalue;
    static volatile long lastinterrupt;
    static volatile int last_rainTicks_outvalue;
    
    static int rainLastDay;
    static int rainLastHour;
    static int rainLastHourStart;
    static int rainLastDayStart;
    static long secsClock;
    static unsigned long outLoopTimer;
    
    // 私有函数
    static void rainTick();
    static void calculateRainfall();
    static void updateSecsClock();
    
public:
    // 初始化函数
    static void begin(byte pin);
    
    // 更新函数
    static void update();
    
    // 获取降雨量函数
    static float getRainfallTotal();           // 总降雨量(mm)
    static float getRainfallLastHour();        // 最近1小时降雨量(mm)
    static float getRainfallLastDay();         // 最近24小时降雨量(mm)
    static float getRainfallTotalInches();     // 总降雨量(英寸)
    static int getRainTicks();                 // 总雨滴计数
    
    // 打印函数
    static void printRainfall();
    static void printRainfallDetailed();
    
    // 重置函数
    static void resetTotal();
    static void resetAll();
    
    // 状态检查函数
    static bool isDataReady();
};

#endif