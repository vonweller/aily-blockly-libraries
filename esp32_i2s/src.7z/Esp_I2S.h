#ifndef ESP_I2S_H
#define ESP_I2S_H

#include "driver/i2s.h"
#include <Arduino.h>
#include "SD.h"
#include "FS.h"

// 音符频率定义 (Hz)
#define NOTE_C4  261.63
#define NOTE_D4  293.66
#define NOTE_E4  329.63
#define NOTE_F4  349.23
#define NOTE_G4  392.00
#define NOTE_A4  440.00
#define NOTE_B4  493.88
#define NOTE_C5  523.25

// 节拍时长定义 (ms)
#define BEAT_WHOLE      2000    // 全音符 2秒
#define BEAT_HALF       1000    // 半音符 1秒  
#define BEAT_QUARTER    500     // 四分音符 0.5秒
#define BEAT_EIGHTH     250     // 八分音符 0.25秒
#define BEAT_SIXTEENTH  125     // 十六分音符 0.125秒

// 音符结构
struct Note {
    float freq;
    uint32_t duration;
};

class EspI2S {
private:
    // 录音相关私有成员
    int bclk_pin;
    int ws_pin;
    int din_pin;
    int sample_rate;
    int buffer_size;
    int16_t* sampleBuffer;
    bool initialized;
    
    // 统计数据
    float avgLevel;
    float peakLevel;
    float rmsLevel;
    float noiseFloor;
    unsigned long totalSamples;
    
    // 录制相关
    File audioFile;
    bool recording;
    uint32_t recordedBytes;
    unsigned long recordStartTime;
    unsigned long maxRecordDuration;
    String currentFileName;
    
    // 功放相关私有成员
    int speaker_bclk;
    int speaker_lrc;
    int speaker_dout;
    bool speakerInitialized;
    bool playingAudio;
    float volume;
    
    // 音乐播放相关
    Note* currentMelody;
    int melodyLength;
    int currentNoteIndex;
    unsigned long noteStartTime;
    bool melodyPlaying;
    bool melodyLoop;
    float phase;  // 正弦波相位
    
    // WAV播放相关
    File playbackFile;
    bool playingWav;
    bool paused;
    unsigned long playbackStartTime;
    uint32_t wavDataSize;
    uint32_t wavSampleRate;
    uint16_t wavChannels;
    uint16_t wavBitsPerSample;
    uint32_t playbackPosition;
    
    // 私有方法
    void writeWavHeader(File &file, uint32_t sampleRate, uint16_t bitDepth, uint16_t channels);
    void updateWavHeader(File &file);
    String generateFileName();
    bool writeAudioData();
    void generateSineWave(int16_t* buffer, size_t samples, float freq);
    bool parseWavHeader();
    
public:
     EspI2S(); // 声明无参构造
    ~EspI2S();
    
    // 基础功能
    bool begin(int sampleRate, int bufferSize, int bclk, int ws, int din); // 新增声明
    void end();
    bool isReady();
    
    // 录音功能
    bool readSamples();
    float getAverageLevel();
    float getPeakLevel();
    float getRMSLevel();
    float getDecibels();
    float getPercentage();
    bool isSoundDetected(int threshold = 1000);
    String getQualityLevel();
    float getSNR();
    float getLowFreqEnergy();
    float getMidFreqEnergy();
    float getHighFreqEnergy();
    void setThreshold(int threshold);
    void calibrateNoiseFloor();
    String getStatusString();
    unsigned long getSampleCount();
    int16_t* getRawBuffer();
    int getBufferSize();
    
    // 录制功能
    bool startRecording(String fileName = "", unsigned long duration = 0);
    bool stopRecording();
    bool isRecording();
    void updateRecording();
    bool listAudioFiles();
    bool deleteAudioFile(String fileName);
    bool fileExists(String fileName);
    uint32_t getFileSize(String fileName);
    String getCurrentFileName();
    unsigned long getRecordedTime();
    uint32_t getRecordedBytes();
    String getRecordingStatus();
    
    // 功放相关新功能
    bool initSpeaker(int bclk, int lrc, int dout);
    void endSpeaker();
    bool isSpeakerReady();
    
    // 音频播放
    bool playTone(float frequency, uint32_t duration);
    bool playNote(float frequency, uint32_t duration);
    bool playMelody(Note* melody, int length, bool loop = false);
    bool stopMelody();
    bool isMelodyPlaying();
    void updateMelody();
    
    // WAV文件播放
    bool playWavFile(String fileName);
    bool stopPlayback();
    bool pausePlayback();
    bool resumePlayback();
    void updatePlayback();
    bool isPlayingWav();
    unsigned long getPlaybackTime();
    uint32_t getFileDuration(String fileName);
    
    // 音量控制
    void setVolume(float vol);  // 0.0 - 1.0
    float getVolume();
    
    // 预定义音乐
    bool playTwinkleStar(bool loop = false);
    bool playHappyBirthday(bool loop = false);
    bool playBeep(uint32_t duration = 200);
    bool playSuccess();
    bool playError();
    
    // 播放状态
    String getPlayingStatus();
    int getCurrentNoteIndex();
    String getCurrentNoteName();
};

#endif