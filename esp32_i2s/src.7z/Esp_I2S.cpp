#include "Esp_I2S.h"
#include <math.h>

EspI2S::EspI2S(int bclk, int ws, int din) {
    bclk_pin = bclk;
    ws_pin = ws;
    din_pin = din;
    sampleBuffer = nullptr;
    initialized = false;
    avgLevel = 0;
    peakLevel = 0;
    rmsLevel = 0;
    noiseFloor = 100;
    totalSamples = 0;
    // 录制相关初始化
    recording = false;
    recordedBytes = 0;
    recordStartTime = 0;
    maxRecordDuration = 0;
    currentFileName = "";
    
    // 添加功放相关初始化
    speaker_bclk = 39;
    speaker_lrc = 40;
    speaker_dout = 38;
    speakerInitialized = false;
    playingAudio = false;
    volume = 0.3;  // 默认音量30%
    
    // 音乐播放初始化
    currentMelody = nullptr;
    melodyLength = 0;
    currentNoteIndex = 0;
    noteStartTime = 0;
    melodyPlaying = false;
    melodyLoop = false;
    phase = 0.0;
    
    // WAV播放初始化
    playingWav = false;
    paused = false;
    playbackStartTime = 0;
    wavDataSize = 0;
    wavSampleRate = 0;
    wavChannels = 0;
    wavBitsPerSample = 0;
    playbackPosition = 0;
}

EspI2S::~EspI2S() {
    if (melodyPlaying) {
        stopMelody();
    }
    if (playingWav) {
        stopPlayback();
    }
    endSpeaker();
    end();
}

bool EspI2S::begin(int sampleRate, int bufferSize) {
    sample_rate = sampleRate;
    buffer_size = bufferSize;
    
    // 分配缓冲区
    sampleBuffer = (int16_t*)malloc(buffer_size * sizeof(int16_t));
    if (!sampleBuffer) {
        Serial.println("❌ 内存分配失败!");
        return false;
    }
    
    // I2S配置
    i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
        .sample_rate = sample_rate,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 8,
        .dma_buf_len = buffer_size
    };
    
    i2s_pin_config_t pin_config = {
        .bck_io_num = bclk_pin,
        .ws_io_num = ws_pin,
        .data_out_num = I2S_PIN_NO_CHANGE,
        .data_in_num = din_pin
    };
    
    // 安装I2S驱动
    esp_err_t err = i2s_driver_install(I2S_NUM_0, &i2s_config, 0, NULL);
    if (err != ESP_OK) {
        Serial.printf("❌ I2S驱动安装失败: %s\n", esp_err_to_name(err));
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }
    
    // 设置I2S引脚
    err = i2s_set_pin(I2S_NUM_0, &pin_config);
    if (err != ESP_OK) {
        Serial.printf("❌ I2S引脚设置失败: %s\n", esp_err_to_name(err));
        i2s_driver_uninstall(I2S_NUM_0);
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }
    
    initialized = true;
    Serial.println("✅ EspI2S 初始化成功");
    Serial.printf("📍 引脚配置: BCLK=%d, WS=%d, DIN=%d\n", bclk_pin, ws_pin, din_pin);
    Serial.printf("🎵 采样率: %d Hz, 缓冲区: %d 样本\n", sample_rate, buffer_size);
    
    return true;
}

void EspI2S::end() {
    if (initialized) {
        i2s_driver_uninstall(I2S_NUM_0);
        initialized = false;
        Serial.println("🔌 I2S驱动已卸载");
    }
    if (sampleBuffer) {
        free(sampleBuffer);
        sampleBuffer = nullptr;
    }
}

bool EspI2S::isReady() {
    return initialized && (sampleBuffer != nullptr);
}

bool EspI2S::readSamples() {
    if (!initialized || !sampleBuffer) {
        return false;
    }
    
    size_t bytesRead;
    esp_err_t result = i2s_read(I2S_NUM_0, sampleBuffer, 
                               buffer_size * sizeof(int16_t), 
                               &bytesRead, portMAX_DELAY);
    
    if (result != ESP_OK) {
        Serial.printf("⚠️ I2S读取错误: %s\n", esp_err_to_name(result));
        return false;
    }
    
    // 计算统计数据
    int32_t sum = 0;
    int64_t sumSquares = 0;
    int16_t maxVal = 0;
    int16_t minVal = 32767;
    
    for (int i = 0; i < buffer_size; i++) {
        int16_t sample = abs(sampleBuffer[i]);
        sum += sample;
        sumSquares += (int64_t)sample * sample;
        
        if (sample > maxVal) maxVal = sample;
        if (sampleBuffer[i] < minVal) minVal = sampleBuffer[i];
    }
    
    avgLevel = (float)sum / buffer_size;
    peakLevel = maxVal;
    rmsLevel = sqrt((float)sumSquares / buffer_size);
    totalSamples += buffer_size;
    
    return true;
}

float EspI2S::getAverageLevel() {
    return avgLevel;
}

float EspI2S::getPeakLevel() {
    return peakLevel;
}

float EspI2S::getRMSLevel() {
    return rmsLevel;
}

float EspI2S::getDecibels() {
    if (rmsLevel <= 0) return -96.0;
    return 20.0 * log10(rmsLevel / 32767.0);
}

float EspI2S::getPercentage() {
    return (rmsLevel / 32767.0) * 100.0;
}

bool EspI2S::isSoundDetected(int threshold) {
    return avgLevel > threshold;
}

String EspI2S::getQualityLevel() {
    if (avgLevel < 100) return "🔇静音";
    else if (avgLevel < 500) return "🔉微弱";
    else if (avgLevel < 2000) return "🔊正常";
    else if (avgLevel < 8000) return "📢较强";
    else if (avgLevel < 20000) return "🔥很强";
    else return "🚨过载";
}

float EspI2S::getSNR() {
    if (noiseFloor <= 0) return 0;
    return 20.0 * log10(rmsLevel / noiseFloor);
}

float EspI2S::getLowFreqEnergy() {
    if (!sampleBuffer) return 0;
    
    long energy = 0;
    int samples = buffer_size / 3;
    for (int i = 0; i < samples; i++) {
        energy += abs(sampleBuffer[i]);
    }
    return (float)energy / samples;
}

float EspI2S::getMidFreqEnergy() {
    if (!sampleBuffer) return 0;
    
    long energy = 0;
    int start = buffer_size / 3;
    int end = 2 * buffer_size / 3;
    for (int i = start; i < end; i++) {
        energy += abs(sampleBuffer[i]);
    }
    return (float)energy / (end - start);
}

float EspI2S::getHighFreqEnergy() {
    if (!sampleBuffer) return 0;
    
    long energy = 0;
    int start = 2 * buffer_size / 3;
    for (int i = start; i < buffer_size; i++) {
        energy += abs(sampleBuffer[i]);
    }
    return (float)energy / (buffer_size - start);
}

void EspI2S::setThreshold(int threshold) {
    noiseFloor = threshold;
    Serial.printf("🔧 噪声阈值设置为: %d LSB\n", threshold);
}

void EspI2S::calibrateNoiseFloor() {
    if (!initialized) return;
    
    Serial.println("🔧 开始噪声基准校准...");
    Serial.println("   请保持环境安静 3 秒...");
    
    float totalNoise = 0;
    int measurements = 0;
    
    for (int i = 0; i < 30; i++) { // 30次测量，每次100ms
        if (readSamples()) {
            totalNoise += avgLevel;
            measurements++;
        }
        delay(100);
    }
    
    if (measurements > 0) {
        noiseFloor = totalNoise / measurements;
        Serial.printf("✅ 噪声基准校准完成: %.1f LSB\n", noiseFloor);
    } else {
        Serial.println("❌ 校准失败");
    }
}

String EspI2S::getStatusString() {
    if (!initialized) return "未初始化";
    
    String status = "📊 EspI2S 状态:\n";
    status += "   🔌 状态: " + String(initialized ? "正常" : "未初始化") + "\n";
    status += "   📍 引脚: BCLK=" + String(bclk_pin) + ", WS=" + String(ws_pin) + ", DIN=" + String(din_pin) + "\n";
    status += "   🎵 采样率: " + String(sample_rate) + " Hz\n";
    status += "   📦 缓冲区: " + String(buffer_size) + " 样本\n";
    status += "   📈 平均电平: " + String(avgLevel, 1) + " LSB\n";
    status += "   🏔️ 峰值电平: " + String(peakLevel, 1) + " LSB\n";
    status += "   📊 RMS电平: " + String(rmsLevel, 1) + " LSB\n";
    status += "   🔊 分贝值: " + String(getDecibels(), 1) + " dBFS\n";
    status += "   📏 百分比: " + String(getPercentage(), 1) + "%\n";
    status += "   🎯 音质: " + getQualityLevel() + "\n";
    status += "   📊 信噪比: " + String(getSNR(), 1) + " dB\n";
    status += "   🔢 总样本: " + String(totalSamples);
    
    return status;
}

unsigned long EspI2S::getSampleCount() {
    return totalSamples;
}

// 原始数据访问方法
int16_t* EspI2S::getRawBuffer() {
    return sampleBuffer;
}

int EspI2S::getBufferSize() {
    return buffer_size;
}

// 录制功能
bool EspI2S::startRecording(String fileName, unsigned long duration) {
    if (recording) {
        Serial.println("⚠️ 已在录制中");
        return false;
    }
    
    if (!initialized) {
        Serial.println("❌ I2S未初始化");
        return false;
    }
    
    // 生成文件名
    if (fileName == "") {
        currentFileName = generateFileName();
    } else {
        currentFileName = fileName;
        if (!currentFileName.endsWith(".wav")) {
            currentFileName += ".wav";
        }
    }
    
    // 创建文件
    audioFile = SD.open("/" + currentFileName, FILE_WRITE);
    if (!audioFile) {
        Serial.println("❌ 无法创建音频文件");
        return false;
    }
    
    // 设置录制参数
    maxRecordDuration = duration;
    recordedBytes = 0;
    recordStartTime = millis();
    
    // 写入WAV头
    writeWavHeader(audioFile, sample_rate, 16, 1);
    
    recording = true;
    
    Serial.println("🎙️ 开始录制音频");
    Serial.printf("📁 文件: %s\n", currentFileName.c_str());
    if (maxRecordDuration > 0) {
        Serial.printf("⏱️ 最大时长: %.1f 秒\n", maxRecordDuration / 1000.0);
    }
    
    return true;
}

bool EspI2S::stopRecording() {
    if (!recording) {
        return false;
    }
    
    recording = false;
    
    // 更新WAV头
    updateWavHeader(audioFile);
    
    // 关闭文件
    audioFile.close();
    
    unsigned long recordTime = millis() - recordStartTime;
    Serial.println("🛑 录制完成");
    Serial.printf("📁 文件: %s\n", currentFileName.c_str());
    Serial.printf("⏱️ 时长: %.2f 秒\n", recordTime / 1000.0);
    Serial.printf("💾 大小: %.1f KB\n", (recordedBytes + 44) / 1024.0);
    
    return true;
}

bool EspI2S::isRecording() {
    return recording;
}

void EspI2S::updateRecording() {
    if (!recording) return;
    
    // 检查最大录制时长
    if (maxRecordDuration > 0 && (millis() - recordStartTime) >= maxRecordDuration) {
        Serial.println("⏰ 达到最大录制时长，自动停止");
        stopRecording();
        return;
    }
    
    // 读取音频数据并写入文件
    if (readSamples()) {
        writeAudioData();
    }
}

bool EspI2S::writeAudioData() {
    if (!recording || !audioFile) return false;
    
    size_t bytesToWrite = buffer_size * sizeof(int16_t);
    size_t written = audioFile.write((uint8_t*)sampleBuffer, bytesToWrite);
    
    if (written == bytesToWrite) {
        recordedBytes += written;
        return true;
    } else {
        Serial.println("⚠️ 写入音频数据失败");
        return false;
    }
}

void EspI2S::writeWavHeader(File &file, uint32_t sampleRate, uint16_t bitDepth, uint16_t channels) {
    uint32_t fileSize = 44;  // 先写入 WAV 头部，后续再更新文件大小
    uint32_t dataSize = 0;   // 数据区大小
 
    file.seek(0);
    file.write((const uint8_t *)"RIFF", 4);
    file.write((uint8_t *)&fileSize, 4);
    file.write((const uint8_t *)"WAVE", 4);
    file.write((const uint8_t *)"fmt ", 4);
    uint32_t subchunk1Size = 16;
    file.write((uint8_t *)&subchunk1Size, 4);
    uint16_t audioFormat = 1;
    file.write((uint8_t *)&audioFormat, 2);
    file.write((uint8_t *)&channels, 2);
    file.write((uint8_t *)&sampleRate, 4);
    uint32_t byteRate = sampleRate * channels * (bitDepth / 8);
    file.write((uint8_t *)&byteRate, 4);
    uint16_t blockAlign = channels * (bitDepth / 8);
    file.write((uint8_t *)&blockAlign, 2);
    file.write((uint8_t *)&bitDepth, 2);
    file.write((const uint8_t *)"data", 4);
    file.write((uint8_t *)&dataSize, 4);
}

void EspI2S::updateWavHeader(File &file) {
    uint32_t fileSize = file.size() - 8;
    uint32_t dataSize = file.size() - 44;
 
    file.seek(4);
    file.write((uint8_t *)&fileSize, 4);
    file.seek(40);
    file.write((uint8_t *)&dataSize, 4);
}

String EspI2S::generateFileName() {
    unsigned long timestamp = millis();
    return "audio_" + String(timestamp) + ".wav";
}

// 文件管理
bool EspI2S::listAudioFiles() {
    Serial.println("📂 SD卡音频文件列表:");
    File root = SD.open("/");
    if (!root) {
        Serial.println("❌ 无法打开根目录");
        return false;
    }
    
    int fileCount = 0;
    uint32_t totalSize = 0;
    
    File file = root.openNextFile();
    while (file) {
        if (!file.isDirectory()) {
            String fileName = file.name();
            if (fileName.endsWith(".wav")) {
                fileCount++;
                uint32_t fileSize = file.size();
                totalSize += fileSize;
                Serial.printf("   🎵 %s (%.1fKB)\n", fileName.c_str(), fileSize/1024.0);
            }
        }
        file = root.openNextFile();
    }
    
    if (fileCount == 0) {
        Serial.println("   📭 没有找到WAV文件");
    } else {
        Serial.printf("📊 总计: %d个文件, %.1fKB\n", fileCount, totalSize/1024.0);
    }
    
    return true;
}

bool EspI2S::deleteAudioFile(String fileName) {
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    
    String fullPath = "/" + fileName;
    
    if (SD.exists(fullPath)) {
        if (SD.remove(fullPath)) {
            Serial.printf("🗑️ 已删除: %s\n", fileName.c_str());
            return true;
        } else {
            Serial.printf("❌ 删除失败: %s\n", fileName.c_str());
            return false;
        }
    } else {
        Serial.printf("❌ 文件不存在: %s\n", fileName.c_str());
        return false;
    }
}

bool EspI2S::fileExists(String fileName) {
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    return SD.exists("/" + fileName);
}

uint32_t EspI2S::getFileSize(String fileName) {
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    
    File file = SD.open("/" + fileName);
    if (file) {
        uint32_t size = file.size();
        file.close();
        return size;
    }
    return 0;
}

// 录制状态
String EspI2S::getCurrentFileName() {
    return currentFileName;
}

unsigned long EspI2S::getRecordedTime() {
    if (recording) {
        return millis() - recordStartTime;
    }
    return 0;
}

uint32_t EspI2S::getRecordedBytes() {
    return recordedBytes;
}

String EspI2S::getRecordingStatus() {
    if (!recording) return "停止";
    
    String status = "录制中: " + currentFileName;
    status += " (";
    status += String(getRecordedTime() / 1000.0, 1);
    status += "s, ";
    status += String(recordedBytes / 1024.0, 1);
    status += "KB)";
    
    return status;
}

// 功放初始化
bool EspI2S::initSpeaker(int bclk, int lrc, int dout) {
    speaker_bclk = bclk;
    speaker_lrc = lrc;
    speaker_dout = dout;
    
    // I2S功放配置
    i2s_config_t speaker_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
        .sample_rate = 44100,  // 功放使用44.1kHz
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 8,
        .dma_buf_len = 512,
        .use_apll = false
    };
    
    i2s_pin_config_t speaker_pin_config = {
        .bck_io_num = speaker_bclk,
        .ws_io_num = speaker_lrc,
        .data_out_num = speaker_dout,
        .data_in_num = I2S_PIN_NO_CHANGE
    };
    
    // 使用I2S_NUM_1避免与录音冲突
    esp_err_t err = i2s_driver_install(I2S_NUM_1, &speaker_config, 0, NULL);
    if (err != ESP_OK) {
        Serial.printf("❌ 功放I2S驱动安装失败: %s\n", esp_err_to_name(err));
        return false;
    }
    
    err = i2s_set_pin(I2S_NUM_1, &speaker_pin_config);
    if (err != ESP_OK) {
        Serial.printf("❌ 功放I2S引脚设置失败: %s\n", esp_err_to_name(err));
        i2s_driver_uninstall(I2S_NUM_1);
        return false;
    }
    
    speakerInitialized = true;
    Serial.println("🔊 功放初始化成功");
    Serial.printf("📍 功放引脚: BCLK=%d, LRC=%d, DOUT=%d\n", speaker_bclk, speaker_lrc, speaker_dout);
    
    return true;
}

void EspI2S::endSpeaker() {
    if (speakerInitialized) {
        i2s_driver_uninstall(I2S_NUM_1);
        speakerInitialized = false;
        Serial.println("🔌 功放I2S驱动已卸载");
    }
}

bool EspI2S::isSpeakerReady() {
    return speakerInitialized;
}

// 生成正弦波 - 与参考代码相同的逻辑
void EspI2S::generateSineWave(int16_t* buffer, size_t samples, float freq) {
    float phaseIncrement = 2 * PI * freq / 44100.0;  // 44.1kHz采样率
    
    for (int i = 0; i < samples; i++) {
        int16_t sample = volume * 32767.0 * sin(phase);
        buffer[i * 2] = sample;      // 左声道
        buffer[i * 2 + 1] = sample;  // 右声道
        
        phase += phaseIncrement;
        if (phase >= 2 * PI) phase -= 2 * PI;
    }
}

// 播放单音 - 与参考代码相同的逻辑
bool EspI2S::playTone(float frequency, uint32_t duration) {
    if (!speakerInitialized) {
        Serial.println("❌ 功放未初始化");
        return false;
    }
    
    const size_t bufferSamples = 256;
    int16_t audioBuffer[bufferSamples * 2];  // 立体声
    size_t bytesWritten;
    
    unsigned long startTime = millis();
    Serial.printf("🎵 播放音调: %.1fHz, 时长: %dms\n", frequency, duration);
    
    while (millis() - startTime < duration) {
        generateSineWave(audioBuffer, bufferSamples, frequency);
        
        esp_err_t result = i2s_write(I2S_NUM_1, 
                                   audioBuffer, 
                                   bufferSamples * 2 * sizeof(int16_t),
                                   &bytesWritten, 
                                   portMAX_DELAY);
        
        if (result != ESP_OK) {
            Serial.printf("⚠️ 音频输出错误: %s\n", esp_err_to_name(result));
            return false;
        }
    }
    
    return true;
}

bool EspI2S::playNote(float frequency, uint32_t duration) {
    return playTone(frequency, duration);
}

// 播放旋律 - 与参考代码相同的逻辑
bool EspI2S::playMelody(Note* melody, int length, bool loop) {
    if (!speakerInitialized) {
        Serial.println("❌ 功放未初始化");
        return false;
    }
    
    currentMelody = melody;
    melodyLength = length;
    currentNoteIndex = 0;
    noteStartTime = millis();
    melodyPlaying = true;
    melodyLoop = loop;
    phase = 0.0;
    
    Serial.printf("🎼 开始播放旋律: %d个音符\n", length);
    return true;
}

bool EspI2S::stopMelody() {
    melodyPlaying = false;
    currentMelody = nullptr;
    Serial.println("⏹️ 停止播放旋律");
    return true;
}

bool EspI2S::isMelodyPlaying() {
    return melodyPlaying;
}

// 更新旋律播放 - 与参考代码相同的逻辑
void EspI2S::updateMelody() {
    if (!melodyPlaying || !currentMelody || !speakerInitialized) return;
    
    // 检查当前音符是否播放完毕
    if (millis() - noteStartTime >= currentMelody[currentNoteIndex].duration) {
        currentNoteIndex++;
        
        // 检查是否播放完所有音符
        if (currentNoteIndex >= melodyLength) {
            if (melodyLoop) {
                currentNoteIndex = 0;  // 循环播放
                Serial.println("🔄 旋律循环播放");
            } else {
                melodyPlaying = false;
                Serial.println("✅ 旋律播放完成");
                return;
            }
        }
        
        noteStartTime = millis();
        phase = 0.0;  // 🔧 重置相位，避免音符间的突变
        
        // 🔧 输出当前播放的音符信息
        Serial.printf("🎵 播放音符 %d/%d: %.1fHz, %dms\n", 
                     currentNoteIndex + 1, melodyLength,
                     currentMelody[currentNoteIndex].freq,
                     currentMelody[currentNoteIndex].duration);
    }
    
    // 🔧 增大缓冲区，确保连续播放
    const size_t bufferSamples = 512;  // 从128增加到512
    int16_t audioBuffer[bufferSamples * 2];
    size_t bytesWritten;
    
    float currentFreq = currentMelody[currentNoteIndex].freq;
    
    // 🔧 添加音符间的静音间隔
    unsigned long currentTime = millis() - noteStartTime;
    unsigned long noteDuration = currentMelody[currentNoteIndex].duration;
    
    // 音符播放80%的时间，20%是静音间隔
    if (currentTime < noteDuration * 0.8) {
        generateSineWave(audioBuffer, bufferSamples, currentFreq);
    } else {
        // 静音间隔
        memset(audioBuffer, 0, bufferSamples * 2 * sizeof(int16_t));
    }
    
    i2s_write(I2S_NUM_1, 
             audioBuffer, 
             bufferSamples * 2 * sizeof(int16_t),
             &bytesWritten, 
             0);  // 非阻塞写入
}

// 音量控制
void EspI2S::setVolume(float vol) {
    volume = constrain(vol, 0.0, 1.0);
    Serial.printf("🔊 音量设置为: %.1f%%\n", volume * 100);
}

float EspI2S::getVolume() {
    return volume;
}

// 预定义音乐 - 小星星与参考代码相同
bool EspI2S::playTwinkleStar(bool loop) {
    static Note twinkleStar[] = {
        // 小星星一闪一闪亮晶晶
        {NOTE_C4, 600}, {NOTE_C4, 600}, {NOTE_G4, 600}, {NOTE_G4, 600},
        {NOTE_A4, 600}, {NOTE_A4, 600}, {NOTE_G4, 1200},  // 满天都是
        
        {NOTE_F4, 600}, {NOTE_F4, 600}, {NOTE_E4, 600}, {NOTE_E4, 600},
        {NOTE_D4, 600}, {NOTE_D4, 600}, {NOTE_C4, 1200},  // 小星星
        
        {NOTE_G4, 600}, {NOTE_G4, 600}, {NOTE_F4, 600}, {NOTE_F4, 600},
        {NOTE_E4, 600}, {NOTE_E4, 600}, {NOTE_D4, 1200},  // 挂在天空
        
        {NOTE_G4, 600}, {NOTE_G4, 600}, {NOTE_F4, 600}, {NOTE_F4, 600},
        {NOTE_E4, 600}, {NOTE_E4, 600}, {NOTE_D4, 1200},  // 放光明
        
        {NOTE_C4, 600}, {NOTE_C4, 600}, {NOTE_G4, 600}, {NOTE_G4, 600},
        {NOTE_A4, 600}, {NOTE_A4, 600}, {NOTE_G4, 1200},  // 重复第一句
        
        {NOTE_F4, 600}, {NOTE_F4, 600}, {NOTE_E4, 600}, {NOTE_E4, 600},
        {NOTE_D4, 600}, {NOTE_D4, 600}, {NOTE_C4, 1200}   // 结尾
    };
    
    int length = sizeof(twinkleStar) / sizeof(twinkleStar[0]);
    return playMelody(twinkleStar, length, loop);
}

bool EspI2S::playHappyBirthday(bool loop) {
    static Note happyBirthday[] = {
        {NOTE_C4, 200}, {NOTE_C4, 200}, {NOTE_D4, 400},
        {NOTE_C4, 400}, {NOTE_F4, 400}, {NOTE_E4, 800},
        {NOTE_C4, 400}, {NOTE_C4, 400}, {NOTE_D4, 800},
        {NOTE_C4, 400}, {NOTE_G4, 400}, {NOTE_F4, 800}
    };
    
    int length = sizeof(happyBirthday) / sizeof(happyBirthday[0]);
    return playMelody(happyBirthday, length, loop);
}

bool EspI2S::playBeep(uint32_t duration) {
    return playTone(1000, duration);  // 1kHz蜂鸣音
}

bool EspI2S::playSuccess() {
    static Note success[] = {
        {NOTE_C4, 150}, {NOTE_E4, 150}, {NOTE_G4, 150}, {NOTE_C5, 300}
    };
    
    int length = sizeof(success) / sizeof(success[0]);
    return playMelody(success, length, false);
}

bool EspI2S::playError() {
    static Note error[] = {
        {NOTE_G4, 200}, {NOTE_C4, 200}, {NOTE_G4, 200}, {NOTE_C4, 200}
    };
    
    int length = sizeof(error) / sizeof(error[0]);
    return playMelody(error, length, false);
}

// WAV文件播放功能
bool EspI2S::playWavFile(String fileName) {
    if (!speakerInitialized) {
        Serial.println("❌ 功放未初始化");
        return false;
    }
    
    if (playingWav) {
        Serial.println("⚠️ 已在播放中");
        return false;
    }
    
    // 确保文件名有.wav扩展名
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    
    // 打开文件
    playbackFile = SD.open("/" + fileName, FILE_READ);
    if (!playbackFile) {
        Serial.printf("❌ 无法打开文件: %s\n", fileName.c_str());
        return false;
    }
    
    // 读取WAV头
    if (!parseWavHeader()) {
        Serial.println("❌ 无效的WAV文件格式");
        playbackFile.close();
        return false;
    }
    
    // 🔧 重新配置I2S采样率以匹配WAV文件
    i2s_config_t speaker_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
        .sample_rate = wavSampleRate,  // 使用WAV文件的采样率
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 8,
        .dma_buf_len = 512,
        .use_apll = false
    };
    
    // 重新安装I2S驱动
    i2s_driver_uninstall(I2S_NUM_1);
    esp_err_t err = i2s_driver_install(I2S_NUM_1, &speaker_config, 0, NULL);
    if (err != ESP_OK) {
        Serial.printf("❌ I2S重新配置失败: %s\n", esp_err_to_name(err));
        return false;
    }
    
    i2s_pin_config_t speaker_pin_config = {
        .bck_io_num = speaker_bclk,
        .ws_io_num = speaker_lrc,
        .data_out_num = speaker_dout,
        .data_in_num = I2S_PIN_NO_CHANGE
    };
    
    i2s_set_pin(I2S_NUM_1, &speaker_pin_config);
    
    playingWav = true;
    paused = false;
    playbackStartTime = millis();
    playbackPosition = 0;
    
    Serial.printf("🎵 开始播放: %s\n", fileName.c_str());
    Serial.printf("📊 格式: %dHz, %d位, %d声道\n", wavSampleRate, wavBitsPerSample, wavChannels);
    
    return true;
}

bool EspI2S::parseWavHeader() {
    char chunkID[5];
    uint32_t chunkSize;
    char format[5];
    
    // 读取RIFF头
    playbackFile.readBytes(chunkID, 4);
    chunkID[4] = '\0';
    if (strcmp(chunkID, "RIFF") != 0) return false;
    
    playbackFile.read((uint8_t*)&chunkSize, 4);
    
    playbackFile.readBytes(format, 4);
    format[4] = '\0';
    if (strcmp(format, "WAVE") != 0) return false;
    
    // 查找fmt块
    while (playbackFile.available()) {
        playbackFile.readBytes(chunkID, 4);
        chunkID[4] = '\0';
        playbackFile.read((uint8_t*)&chunkSize, 4);
        
        if (strcmp(chunkID, "fmt ") == 0) {
            uint16_t audioFormat;
            playbackFile.read((uint8_t*)&audioFormat, 2);
            playbackFile.read((uint8_t*)&wavChannels, 2);
            playbackFile.read((uint8_t*)&wavSampleRate, 4);
            
            // 跳过其他fmt数据
            playbackFile.seek(playbackFile.position() + chunkSize - 8);
            
        } else if (strcmp(chunkID, "data") == 0) {
            wavDataSize = chunkSize;
            break;
        } else {
            // 跳过未知块
            playbackFile.seek(playbackFile.position() + chunkSize);
        }
    }
    
    return wavDataSize > 0;
}

void EspI2S::updatePlayback() {
    if (!playingWav || paused || !playbackFile) return;
    
    const size_t bufferSamples = 256;
    int16_t audioBuffer[bufferSamples * 2];  // 立体声缓冲区
    size_t bytesRead;
    size_t bytesWritten;
    
    // 读取音频数据
    if (wavChannels == 1) {  // 单声道
        int16_t monoBuffer[bufferSamples];
        bytesRead = playbackFile.read((uint8_t*)monoBuffer, bufferSamples * sizeof(int16_t));
        
        // 转换为立体声
        for (int i = 0; i < bytesRead / 2; i++) {
            audioBuffer[i * 2] = monoBuffer[i] * volume;      // 左声道
            audioBuffer[i * 2 + 1] = monoBuffer[i] * volume;  // 右声道
        }
        
        bytesWritten = (bytesRead / 2) * 2 * sizeof(int16_t);
        
    } else {  // 立体声
        bytesRead = playbackFile.read((uint8_t*)audioBuffer, bufferSamples * 2 * sizeof(int16_t));
        
        // 应用音量
        for (int i = 0; i < bytesRead / 2; i++) {
            audioBuffer[i] = audioBuffer[i] * volume;
        }
        
        bytesWritten = bytesRead;
    }
    
    if (bytesRead > 0) {
        // 🔧 使用阻塞写入确保时序正确
        size_t written;
        esp_err_t result = i2s_write(I2S_NUM_1, audioBuffer, bytesWritten, &written, portMAX_DELAY);
        
        if (result != ESP_OK) {
            Serial.printf("⚠️ I2S写入错误: %s\n", esp_err_to_name(result));
        }
        
        playbackPosition += bytesRead;
        
        // 🔧 添加时序控制 - 根据采样率计算延时
        uint32_t samplesPlayed = bytesRead / (sizeof(int16_t) * wavChannels);
        uint32_t timePerBuffer = (samplesPlayed * 1000) / wavSampleRate;  // 毫秒
        
        // 短暂延时以维持正确的播放速度
        if (timePerBuffer > 0) {
            delay(timePerBuffer / 4);  // 适当的延时
        }
        
    } else {
        // 播放完成
        Serial.println("✅ WAV播放完成");
        stopPlayback();
    }
}

bool EspI2S::stopPlayback() {
    if (!playingWav) return false;
    
    playingWav = false;
    paused = false;
    
    if (playbackFile) {
        playbackFile.close();
    }
    
    Serial.println("⏹️ 停止播放WAV");
    return true;
}

bool EspI2S::pausePlayback() {
    if (!playingWav) return false;
    
    paused = true;
    Serial.println("⏸️ 暂停播放");
    return true;
}

bool EspI2S::resumePlayback() {
    if (!playingWav) return false;
    
    paused = false;
    Serial.println("▶️ 恢复播放");
    return true;
}

bool EspI2S::isPlayingWav() {
    return playingWav;
}

unsigned long EspI2S::getPlaybackTime() {
    if (!playingWav) return 0;
    return millis() - playbackStartTime;
}

uint32_t EspI2S::getFileDuration(String fileName) {
    // 根据文件大小和采样率估算时长
    if (!fileExists(fileName)) return 0;
    
    uint32_t fileSize = getFileSize(fileName);
    if (fileSize < 44) return 0;  // 至少要有WAV头
    
    uint32_t dataSize = fileSize - 44;  // 减去WAV头
    uint32_t duration = (dataSize * 1000) / (44100 * 2);  // 假设44.1kHz 16位
    
    return duration;
}

// 播放状态
String EspI2S::getPlayingStatus() {
    if (playingWav) {
        String status = "播放WAV: ";
        status += String(getPlaybackTime() / 1000.0, 1);
        status += "s";
        return status;
    }
    
    if (!melodyPlaying) return "停止";
    
    String status = "播放中: 音符 ";
    status += String(currentNoteIndex + 1);
    status += "/";
    status += String(melodyLength);
    status += " (";
    status += String(currentMelody[currentNoteIndex].freq, 1);
    status += "Hz)";
    
    return status;
}

int EspI2S::getCurrentNoteIndex() {
    return currentNoteIndex;
}

String EspI2S::getCurrentNoteName() {
    if (!melodyPlaying || !currentMelody) return "";
    
    float freq = currentMelody[currentNoteIndex].freq;
    
    if (abs(freq - NOTE_C4) < 1) return "C4";
    else if (abs(freq - NOTE_D4) < 1) return "D4";
    else if (abs(freq - NOTE_E4) < 1) return "E4";
    else if (abs(freq - NOTE_F4) < 1) return "F4";
    else if (abs(freq - NOTE_G4) < 1) return "G4";
    else if (abs(freq - NOTE_A4) < 1) return "A4";
    else if (abs(freq - NOTE_B4) < 1) return "B4";
    else if (abs(freq - NOTE_C5) < 1) return "C5";
    else return String(freq, 1) + "Hz";
}