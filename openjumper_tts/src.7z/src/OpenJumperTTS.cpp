#include "OpenJumperTTS.h"

/** ������������-Voice broadcast text.
  * @brief ��������
  * @param data Ҫ���ŵ����ݣ����ַ�����ʽ�ṩ
  */
void OpenJumperTTS::PlayText(const char* data) {
  uint8_t* buffer = genTTSBuffer(data);// �������ɻ��������� 
  sendTTSBuffer(buffer);// ���ͻ��������� 
  free(buffer);// �ͷŻ������ڴ�
}

/** ������������-Voice broadcasting numbers.
  * @brief ��������
  * @param data Ҫ���ŵ����ݣ���������ʽ�ṩ
  */
void OpenJumperTTS::PlayNumber(int numberString) {
  
  char NumberS[5];
  snprintf(NumberS, sizeof(NumberS), "%d", numberString);// ��ֵת��Ϊ�ַ���

  uint8_t* buffer = genTTSBuffer(NumberS);// �������ɻ��������� 
  sendTTSBuffer(buffer);// ���ͻ��������� 
  free(buffer);// �ͷŻ������ڴ�
}

/** �����ϳɿ���-Speech synthesis control.
  * 
  * @param command One of the following, 
  * 
  *  *  PLAY_STOP      //ֹͣ
  *  *  PLAY_PAUSE     //��ͣ     
  *  *  PLAY_CONTINUE  //����       
  * 
  */
void OpenJumperTTS::playcontrol(byte command){
  while(this->waitUntilAvailable(10)) this->read();
    this->write((byte)0xFD);
    this->write((byte)0x00);
    this->write((byte)0x01);
    this->write(command);
}

/** ֹͣ����-Speech synthesis control.
  *       
  * 
  */
void OpenJumperTTS::playStop(void){
  this->write(0xFD);
  this->write((byte)0x00);
  this->write(0x01);
  this->write(0x02);
}

/** ��ͣ����-Speech synthesis control.
  *       
  * 
  */
void OpenJumperTTS::playPause(void){
  this->write(0xFD);
  this->write((byte)0x00);
  this->write(0x01);
  this->write(0x03);
}

/** ��������-Speech synthesis control.
  *       
  * 
  */
void OpenJumperTTS::playContinue(void){
  this->write(0xFD);
  this->write((byte)0x00);
  this->write(0x01);
  this->write(0x04);
}

/** ��������-system parameter setting.
  * 
  * @param speechSpeed Set the volume to a specific level (1 to 10) 
  */
void  OpenJumperTTS::setspeechSpeed(byte speechSpeed){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x06);

  this->write((byte)0x01);
  
  this->write((byte)0x01);
  this->write((byte)0x5B);

  this->write(0x73);
  this->write(speechSpeed + 48);

  this->write((byte)0x5D);
}

/** �������-system parameter setting.
  * 
  * @param intonation Set the volume to a specific level (1 to 10) 
  */
void  OpenJumperTTS::setIntonation(byte intonation){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x06);

  this->write((byte)0x01);
  
  this->write((byte)0x01);
  this->write((byte)0x5B);

  this->write(0x74);
  this->write(intonation + 48);

  this->write((byte)0x5D);
}

/** ��������-system parameter setting.
  * 
  * @param volumeVlaue Set the volume to a specific level (1 to 10) 
  */
void  OpenJumperTTS::setVolume(byte volumeVlaue){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x06);

  this->write((byte)0x01);
  
  this->write((byte)0x01);
  this->write((byte)0x5B);

  this->write(0x76);
  this->write(volumeVlaue + 48);

  this->write((byte)0x5D);
}

/** �ָ�Ĭ��ֵ-Restore default values.
  * 
  */
void OpenJumperTTS::RestoreDefaultValues(void){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x12);

  this->write((byte)0x01);
  
  this->write((byte)0x01);

  this->write((byte)0x5B);
  this->write((byte)0x67);
  this->write((byte)0x31);
  this->write((byte)0x5D);

  this->write((byte)0x5B);
  this->write((byte)0x73);
  this->write((byte)0x35);
  this->write((byte)0x5D);

  this->write((byte)0x5B);
  this->write((byte)0x74);
  this->write((byte)0x35);
  this->write((byte)0x5D);

  this->write((byte)0x5B);
  this->write((byte)0x76);
  this->write((byte)0x35);
  this->write((byte)0x5D);
}

/** ������ʾ��-Play prompt sound.
 * 
 * @param soundType One of the following, 
  *  *  VOICE_Ringtones      //����
  *  *  VOICE_PromptSound //��ʾ��     
  *  *  VOICE_WarningSound     //��ʾ�� 
  * 
  * @param soundnumber Set the volume to a specific level (31 to 35), 
  */
void OpenJumperTTS::PlayPromptSound(byte soundType,byte soundnumber){
  while(this->waitUntilAvailable(10)) this->read();
  size_t textLength;
  uint8_t rings[11]   = {0xFD,0X00,0X08,0X01,0X01,0X72,0X69,0X6E,0X67,0X5F};
  uint8_t message[14] = {0xFD,0X00,0X0B,0X01,0X01,0X6D,0X65,0X73,0X73,0X61,0x67,0x65,0x5F};
  uint8_t alert[12]   = {0xFD,0X00,0X09,0X01,0X01,0X61,0X6C,0X65,0X72,0X74,0x5F};

  switch(soundType){
  case 1: 
      textLength = 10;
      rings[textLength] = (uint8_t)soundnumber + 48;
      for (uint8_t i = 0; i < textLength+1; i++) {
        this->write(rings[i]);
      }
      break;
  case 2: 
      textLength = 13;
      message[textLength] = (uint8_t)soundnumber + 48;
      for (uint8_t i = 0; i < textLength+1; i++) {
        this->write(message[i]);
      }
      break;
  case 3: 
      textLength = 11;
      alert[textLength] = (uint8_t)soundnumber + 48;
      for (uint8_t i = 0; i < textLength+1; i++) {
        this->write(alert[i]);
      }
      break;
  default :;break;
 }

}

int OpenJumperTTS::waitUntilAvailable(unsigned long maxWaitTime)
{
  unsigned long startTime;
  int c = 0;
  startTime = millis();
  do {
    c = this->available();
    if (c) break;
    } while(millis() - startTime < maxWaitTime);

    return c;
  }
 
/**
 * �������ݵ�TTSģ�顣
 * @param buffer Ҫ���͵��ı���
*/
void OpenJumperTTS::sendTTSBuffer(uint8_t* buffer) {
  // ���㻺������ʵ�ʳ���
  int length = (buffer[1] << 8) | buffer[2];
  for (int i = 0; i < length + 3; i++) {
    this->write(buffer[i]);
  }
}

uint8_t* OpenJumperTTS::genTTSBuffer(const char* content) {
  uint8_t buffer_head[] = {0xFD};
  uint8_t buffer_cmd[] = {0x01};
  uint8_t buffer_encode[] = {0x04};

  int content_length = strlen(content);
  int buffer_text_length = content_length + 2;
  uint8_t highByte = buffer_text_length >> 8;
  uint8_t lowByte = buffer_text_length & 0xFF;
  uint8_t buffer_length[] = {highByte, lowByte};

  uint8_t* buffer = (uint8_t*)malloc(3 + content_length + 3);
  int index = 0;
  buffer[index++] = buffer_head[0];
  buffer[index++] = buffer_length[0];
  buffer[index++] = buffer_length[1];
  buffer[index++] = buffer_cmd[0];
  buffer[index++] = buffer_encode[0];
  for (int i = 0; i < content_length; i++) {
    buffer[index++] = content[i];
  }
  return buffer;
}
