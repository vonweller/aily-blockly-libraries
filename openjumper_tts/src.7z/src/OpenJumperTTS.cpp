#include "OpenJumperTTS.h"

/** 语音播报文字-Voice broadcast text.
  * @brief 语音播放
  * @param data 要播放的数据，以字符形式提供
  */
void OpenJumperTTS::PlayText(const char* data) {
  uint8_t* buffer = genTTSBuffer(data);//调用生成的缓冲区函数
  sendTTSBuffer(buffer);//发送缓冲区数据
  free(buffer);//释放缓冲区内存

}

/** 语音播报数字-Voice broadcasting numbers.
  * @brief 语音播报
  * @param data 要播放的数据，以数组形式提供
  */
void OpenJumperTTS::PlayNumber(int numberString) {
  char NumberS[5];
  snprintf(NumberS, sizeof(NumberS), "%d", numberString);//将值转换成字符串

  uint8_t* buffer = genTTSBuffer(NumberS);//调用生成的缓冲区函数
  sendTTSBuffer(buffer);//发送缓冲区数据
  free(buffer);//释放缓冲区内存

}

/** 语音合成控制-Speech synthesis control.
  * 
  * @param command One of the following, 
  * 
  *  *  PLAY_STOP     //停止
  *  *  PLAY_PAUSE     //暂停
  *  *  PLAY_CONTINUE  //继续
  */
void OpenJumperTTS::playcontrol(byte command){
  while(this->waitUntilAvailable(10)) this->read();
    this->write((byte)0xFD);
    this->write((byte)0x00);
    this->write((byte)0x01);
    this->write((byte)command);
}


/** 语速设置-system parameter setting.
  * 
  * @param speechSpeed Set the volume to a specific level (1 to 10) 
  */
void  OpenJumperTTS::setspeechSpeed(byte speechSpeed){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x06);

  this->write((byte)0x01);
  
  this->write((byte)0x04);//
  this->write((byte)0x5B);

  this->write(0x73);
  this->write(speechSpeed + 48);

  this->write((byte)0x5D);
}

/** 语调设置-system parameter setting.
  * 
  * @param intonation Set the volume to a specific level (1 to 10) 
  */
void  OpenJumperTTS::setIntonation(byte intonation){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x06);

  this->write((byte)0x01);
  
  this->write((byte)0x04);//
  this->write((byte)0x5B);

  this->write(0x74);
  this->write(intonation + 48);

  this->write((byte)0x5D);
}

/** 音量设置-system parameter setting.
  * 
  * @param volumeVlaue Set the volume to a specific level (1 to 10) 
  */
void  OpenJumperTTS::setVolume(byte volumeVlaue){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x06);

  this->write((byte)0x01);
  
  this->write((byte)0x04);//
  this->write((byte)0x5B);

  this->write(0x76);
  this->write(volumeVlaue + 48);

  this->write((byte)0x5D);
}

/** 恢复默认值-Restore default values.
  * 
  */
void OpenJumperTTS::RestoreDefaultValues(void){
  while(this->waitUntilAvailable(10)) this->read();

  this->write((byte)0xFD);

  this->write((byte)0x00);
  this->write((byte)0x12);

  this->write((byte)0x01);
  
  this->write((byte)0x04);

  this->write((byte)0x5B);
  this->write((byte)0x67);
  this->write((byte)0x31);
  this->write((byte)0x5D);

  this->write((byte)0x5B);
  this->write((byte)0x73);
  this->write((byte)0x35);
  this->write((byte)0x5D);

  this->write((byte)0x5B);
  this->write((byte)0x74);
  this->write((byte)0x35);
  this->write((byte)0x5D);

  this->write((byte)0x5B);
  this->write((byte)0x76);
  this->write((byte)0x35);
  this->write((byte)0x5D);
}

/** 播放提示音-Play prompt sound.
 * 
 * @param soundType One of the following, 
  *  *  VOICE_Ringtones      //铃声
  *  *  VOICE_PromptSound //提示音 
  *  *  VOICE_WarningSound     //警示音
  * 
  * @param soundnumber Set the volume to a specific level (31 to 35), 
  */
void OpenJumperTTS::PlayPromptSound(byte soundType,byte soundnumber){
  
  while(this->waitUntilAvailable(10)) this->read();
  
  size_t textLength;
  uint8_t rings[11]   = {0xFD,0X00,0X08,0X01,0X04,0X72,0X69,0X6E,0X67,0X5F};
  uint8_t message[14] = {0xFD,0X00,0X0B,0X01,0X04,0X6D,0X65,0X73,0X73,0X61,0x67,0x65,0x5F};
  uint8_t alert[12]   = {0xFD,0X00,0X09,0X01,0X04,0X61,0X6C,0X65,0X72,0X74,0x5F};

  switch(soundType){
  case 1: 
      textLength = 10;
      rings[textLength] = (uint8_t)soundnumber + 48;
      for (uint8_t i = 0; i < textLength+1; i++) {
        this->write(rings[i]);
      }
      break;
  case 2: 
      textLength = 13;
      message[textLength] = (uint8_t)soundnumber + 48;
      for (uint8_t i = 0; i < textLength+1; i++) {
        this->write(message[i]);
      }
      break;
  case 3: 
      textLength = 11;
      alert[textLength] = (uint8_t)soundnumber + 48;
      for (uint8_t i = 0; i < textLength+1; i++) {
        this->write(alert[i]);
      }
      break;
  default :;break;
 }

 while (true) {
  if (this->waitUntilAvailable(10)) { //
    if (this->read() == 0x4F) { //
      break; //
    }
  }
}

}

int OpenJumperTTS::waitUntilAvailable(unsigned long maxWaitTime)
{
  unsigned long startTime;
  int c = 0;
  startTime = millis();
  do {
    c = this->available();
    if (c) break;
    } while(millis() - startTime < maxWaitTime);

    return c;
  }
 
/**
 * 发送数据到TTS模块
 * @param buffer 要发送的文本
*/
void OpenJumperTTS::sendTTSBuffer(uint8_t* buffer) {
  //计算缓冲区的实际长度
  int length = (buffer[1] << 8) | buffer[2];
  for (int i = 0; i < length + 3; i++) {
    this->write(buffer[i]);
  }
}

uint8_t* OpenJumperTTS::genTTSBuffer(const char* content) {
  uint8_t buffer_head[] = {0xFD};
  uint8_t buffer_cmd[] = {0x01};
  uint8_t buffer_encode[] = {0x04};

  int content_length = strlen(content);
  int buffer_text_length = content_length + 2;
  uint8_t highByte = buffer_text_length >> 8;
  uint8_t lowByte = buffer_text_length & 0xFF;
  uint8_t buffer_length[] = {highByte, lowByte};

  uint8_t* buffer = (uint8_t*)malloc(3 + content_length + 3);
  int index = 0;
  buffer[index++] = buffer_head[0];
  buffer[index++] = buffer_length[0];
  buffer[index++] = buffer_length[1];
  buffer[index++] = buffer_cmd[0];
  buffer[index++] = buffer_encode[0];
  for (int i = 0; i < content_length; i++) {
    buffer[index++] = content[i];
  }
  return buffer;
}
