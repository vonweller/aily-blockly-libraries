#ifndef OpenJumperPS3_h
#define OpenJumperPS3_h

#include <Wire.h>

class OpenJumperPS3 {
public:
    struct PS3Data {
        bool up;
        bool down;
        bool left;
        bool right;
        bool triangle;
        bool cross;
        bool square;
        bool circle;
        bool l1;
        bool l2;
        bool r1;
        bool r2;
        bool l3;
        bool r3;
        bool select;
        bool start;
        uint8_t lx;
        uint8_t ly;
        uint8_t rx;
        uint8_t ry;
    };

    OpenJumperPS3();
    void run();
    PS3Data ps3Data;

private:
    char receive_Buff[9];
    bool button[16];
    
};

#endif