#include "OpenJumperPS3.h"
#include "Arduino.h"

OpenJumperPS3::OpenJumperPS3() {
    receive_Buff[8] = '\0';
    for (int i = 0; i < 16; i++) {
        button[i] = 0;
    }
}

void OpenJumperPS3::run() {
    Wire.requestFrom(2, 8);
    delay(20);
    if (Wire.available()) {
        char *p = receive_Buff;
        while (Wire.available() > 0 && p < &receive_Buff[8]) {
            *p = Wire.read();
            p++;
        }
        if (p == &receive_Buff[8]) {
            *p = '\0';
        }
        byte button1 = receive_Buff[1];
        byte button2 = receive_Buff[2];
        for (int a = 0; a < 16; a++) {
            if ((a >= 0) && (a < 8)) {
                button[a] = button1 % 2;
                button1 = button1 >> 1;
            } else if ((a >= 8) && (a < 16)) {
                button[a] = button2 % 2;
                button2 = button2 >> 1;
            }
        }
        ps3Data = {
            button[7], button[6], button[5], button[4],
            button[3], button[2], button[1], button[0],
            button[15], button[14], button[13], button[12],
            button[11], button[10], button[9], button[8],
            receive_Buff[3], receive_Buff[4], receive_Buff[5], receive_Buff[6]
        };
    }
}
